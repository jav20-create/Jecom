Note of the author
This is demo font for PERSONAL USE ONLY! But any donation are very appreciate.

Paypal Account for donation :  https://paypal.me/yuniletter

For Full Version You can visit my store on:
https://www.creativefabrica.com/product/monogram-gold/ref/453441/

and for other licence please contact me at: letterdaystudio@gmail.com

Thank You